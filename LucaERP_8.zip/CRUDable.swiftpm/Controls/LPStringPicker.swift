import SwiftUI

struct LPStringPicker:View{
    var label:String
    @Binding var value:String
    var choiceLabels:[String]
    var isActive:Bool = true
    
    var body: some View{
        HStack{
            Picker(label, selection: $value){ 
                ForEach(choiceLabels,id:\.self){ choice in
                    Text(choice)
                        .tag(choice)
                }
            }
                .lpFieldModifier(label: label, value: value, isActive: isActive)
                Spacer()
        }
    }
}




#Preview{
    LPStringPicker(label: "Choices", value: .constant("mo"), choiceLabels: ["eeny","meeny","miny","mo"],isActive:true)
}

