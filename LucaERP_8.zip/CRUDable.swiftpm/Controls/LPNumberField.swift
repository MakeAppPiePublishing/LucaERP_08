import SwiftUI

struct LPNumberField:View{
    var label:String
    @Binding var value:Float
    var isActive:Bool = true
    
    var formatter:Formatter{
            let formatter = NumberFormatter()
            formatter.numberStyle = .decimal
            return formatter
    }
    
    var body: some View{
        HStack{
            TextField(label,value:$value,formatter: formatter)
                .lpFieldModifier(label: label, value: formatter.string(for: value) ?? "", isActive: isActive)
                .keyboardType(.decimalPad)
        }
    }
}

#Preview{
    LPNumberField(label: "Number", value: .constant(314), isActive: true)
}
