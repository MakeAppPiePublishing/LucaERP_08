import SwiftUI

struct ErrorMessageBox:View{
    var error:ErrorType
    @State var errorMessage = "" 
    @Binding var isPresented:Bool
    var isNotIpad:Bool{
        @Environment(\.verticalSizeClass) var vsc
        @Environment(\.horizontalSizeClass) var hsc
        return vsc != .regular && hsc != .regular
    }
    var body: some View{
        VStack{
            Text("Error").font(.title)
            Image(systemName: "exclamationmark.triangle.fill")
                .imageScale(.large)
                .foregroundStyle(.yellow)
            Text(error.rawValue)
                .font(.headline).fontWeight(.heavy)
            Text(errorMessage)
            if isNotIpad{
                Button("OK"){
                    isPresented = false
                }
                .font(.headline)
                .padding()
                .background(.regularMaterial)
                .cornerRadius(10)
            }
        }
    }
}

#Preview{
    ErrorMessageBox(error: .recordExists, isPresented: .constant(true))
}
