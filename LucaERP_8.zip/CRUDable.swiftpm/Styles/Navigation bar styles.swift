import SwiftUI

struct FileNavButtonModifier:ViewModifier{
    var label:String = ""
    var disabled:Bool = false
    func body(content: Content) -> some View {
        VStack{
            content
                .imageScale(.large)
                .padding(5)
                .frame(width: 50,height:50)
                .background(.blue, in: RoundedRectangle(cornerRadius: 8))
                .foregroundStyle(.white)
                .disabled(disabled)
                .opacity(disabled ? 0.5: 1)
            Text(label)
                .font(.caption2)
        }
    }
}

extension View{
    func fileNavButtonModifier(label:String = "", disabled:Bool = false)-> some View{
        return self.modifier(FileNavButtonModifier(label:label,disabled:disabled))
    }
}
