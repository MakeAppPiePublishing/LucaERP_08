import SwiftUI

struct TestModelRow:Identifiable,Activatable,Equatable{
    var id:Int
    var isActive: Bool = true
    var name:String
}


class TestModel:Crudable{
    typealias Row = TestModelRow
    var table:[Row] = []
    var blank:Row{
        TestModelRow(id: -1, isActive: false, name: "")
    }
}


