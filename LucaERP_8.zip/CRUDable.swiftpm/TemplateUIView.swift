//
//  SwiftUIView.swift
//  My App
//
//  Created by Steven Lipton on 6/3/25.
//

import SwiftUI

struct TemplateUIView: View{
    @State var model:TestModel = TestModel()
    @State var selectedRow = TestModel().blank
    
//-----------------State Variables for custom UI
    @State var name:String = ""
    @State var id:Int = 0
    @State var isActive = true
//----------------- End of State variables
    
    
    //State variables for template
    /// The display mode status
    @State private var displayMode:CRUDAction = .search
    ///Error handling - error message
    @State private var errorType:ErrorType = .noError
    ///Error handling and messaging in error bar.
    @State private var message:String = "LucaP ERP ready"
    /// Indicates the navigation action required
    @State private var navigationAction:NavigationAction = .noAction
    //--- flags
    /// read only form
    /// - used by fields to determine if read-only
    /// - `false` is read-only
    @State private var formActive:Bool = true
    /// keys read only
    /// - used by keys to determine read write independent of `formActive`
    /// - `false` is read-only -- use for keys determined by system
    @State private var keyActive:Bool = false
    
    /// - TODO: for noe set to @State. chang to @Binding in final version
    @State var isPresented:Bool = true
    
    /// flag to perform action
    @State private var doAction:Bool = false
    
    /// the description of the view in navigation
    @State var navigationDescription:String = "test view"
    
    
    var body: some View {
        
        VStack{
            ContentHeaderView(path: $navigationDescription)
            LPNavigationBar(navAction: $navigationAction, displayMode:$displayMode)
            
// ----------------- code for the forms goes here
            VStack(alignment:.leading){
                LPIntField(label: "ID", value: $id, isActive: keyActive)
                LPTextField(label: "Name", contents: $name, isActive: formActive)
                LPCheckBox(label: "Active", value: $isActive, isActive: true)
           
            .padding()
            
            Text("Names").font(.title2)
            Divider()
            List(model.table){row in
                HStack{
                    Text(row.id,format:.number)
                    Text(row.name)
                    Spacer()
                    LPCheckBox(label: "Active", value: .constant(row.isActive), isActive: false)
                }
                .fontWeight(row.isActive ? .bold : .light)
                .foregroundStyle(row.isActive ? .primary : .secondary)
            }
            }
            
//--------------------- end of form code
            Spacer()
            LPBottomToolbar(error:$errorType,message:$message,action:$displayMode,isPresented: $isPresented,doAction: $doAction)
        }
        .onAppear{
            refreshUI()
        }
        .onChange(of: selectedRow) {
            refreshUI()
        }
        .onChange(of:doAction){
            if doAction{
                performAction()
            }
        }
        .onChange(of:displayMode){
            changeDisplayMode()
        }
        .onChange(of:navigationAction){
            if navigationAction != .noAction{
                rowNavigation()
            }
        }
        
    }
 //------- Change `refreshUI` to reflect the properties from your model displayed
    func refreshUI(){
        name = selectedRow.name
        id = selectedRow.id
        isActive = selectedRow.isActive
    }

    
//---------- Modify display mode if necessary, if a system generated key, `keyActive` should remain false.
    func changeDisplayMode(){
        switch displayMode{
        case .add:                              // if adding, display a new row and open for editing
            let ids:[Int] = model.table.map({$0.id})
            let newID = (ids.max() ?? 0) + 1
            selectedRow = TestModelRow(id: newID,isActive: true,name:"")
            formActive = true
            keyActive = false
            message = "Add new"
        case .update:                           // if model exists, open for editing, otherwise search
            if model.exists(id: id) {
                formActive = true
                keyActive = false
            } else {
                displayMode = .search
                message = "Search"
            }
        case .search:
            selectedRow = model.blank
            formActive = false
            displayMode = .view
            message = "Search"
        case .view:
            // if the `id` is not a valid entry, go into search mode if valid view everything
            if model.exists(id: id){
                formActive = false
                keyActive = false
                message = "View: \(id)"
            } else {
                displayMode = .search
                message = "Search for account number"
            }
        default:
            //do nothing
            formActive = formActive
        }
    }
    
    func rowNavigation(){
        displayMode = .view
        switch navigationAction {
        case .first:
            selectedRow = model.firstRow()
            message = "First Account"
        case .previous:
            // when blank, go to first row
            if model.exists(id:id){
                selectedRow = model.previousRow(id: id)
            } else {
                selectedRow = model.firstRow()
            }
        case .next:
            if model.exists(id:id){
                selectedRow = model.nextRow(id:id)
            } else {
                selectedRow = model.lastRow()
            }
        case .last:
            selectedRow = model.lastRow()
            message = "Last Account"
        default:
            //do nothing
            navigationAction = .noAction
        }
        //reset the action
        navigationAction = .noAction
    }
    
    func performAction(){
//---------- Change the `newRow` to initialize to your Row's struct
        let newRow = TestModelRow(id: id, isActive: isActive, name: name)
        switch displayMode{
        case .add:
            errorType = model.add(row:newRow)
            if errorType == .noError{
                message = "\(id) added sucessfully"
                displayMode = .update
            } else {
                message = "\(id) not added"
            }
            displayMode = .view
        case .update:
            errorType = model.update(id: id, newRow: newRow, isActive: true)
            if errorType == .noError{
                message = "\(id) updated sucessfully"
            } else {
                message = "\(id) not updated"
            }
            
        case .search:
            let result = model.find(id:id)
            errorType = result.errorType
            if errorType == .noError{
                selectedRow = result.row
                message = "\(id) found"
            } else {
                message = "\(id) not found"
            }
        case .delete:
            errorType = model.remove(id:id)
            if errorType == .noError{
                message = "Sucessfully deleted"
            } else {
                message = "No action taken"
            }
        default:
            // do nothing
            break
        }
        doAction = false
    }
    
    
}

#Preview {
    TemplateUIView()
}
