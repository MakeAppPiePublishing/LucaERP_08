//
//  Crudable.swift
//  LucaP - An ERP to learn from
//
//  Created by Steven Lipton on 5/23/25.
//  A protocol for ensuring conformity in views and models

protocol Crudable:Identifiable{
    /// the type for the record in the table
    associatedtype Row:Identifiable,Activatable
    
    var table:[Row]{get set}
    var blank:Row{get}
    
    // C is for Create
    mutating func add(row:Row)-> ErrorType
    
    // R is for Read
    func exists(id:Row.ID)-> Bool
    func find(id:Row.ID) -> (row:Row,errorType:ErrorType)
    func index(id:Row.ID)->Int!
    func firstRow()->Row
    func lastRow()->Row
    func nextRow(id:Row.ID)->Row
    func previousRow(id:Row.ID) -> Row
    
    // U is for update
    mutating func update(oldRow:Row,newRow:Row,isActive:Bool)->ErrorType
    
    mutating func update(id:Row.ID,newRow:Row,isActive:Bool)->ErrorType

    // D is for delete
    mutating func remove(id:Row.ID)->ErrorType
}

extension Crudable{
     //C is for create
     mutating func add(row:Row)-> ErrorType{
         if self.exists(id: row.id){
            return .recordExists
        } else {
            table.append(row)
        }
        return .noError
    }
    
    func exists(id:Row.ID)-> Bool{
        table.contains(where:{$0.id == id})
    }
    
    func find(id:Row.ID) -> (row:Row,errorType:ErrorType){
        if let row = table.first(where: {$0.id == id}){
            return (row:row,errorType:.noError)
        } else {
            return (row:blank,errorType:.recordNotFound)
        }
    }
    
    func index(id:Row.ID)->Int!{
        table.firstIndex(where: {$0.id == id})
    }
    
    func firstRow()->Row{
        return table.first ?? blank
    }
    
    func lastRow()->Row{
        return table.last ?? blank
    }
    
    func nextRow(id:Row.ID)->Row{
        if let index = index(id:id){
            let newIndex = index + 1
            if newIndex != table.count{
                return table[newIndex]
            } else {
                return table.first ?? blank
            }
        }
        return blank
    }
    
    func previousRow(id:Row.ID)->Row{
        if let index = index(id:id) {
            let newIndex = index - 1
            if newIndex >= 0{
                return table[newIndex]
            } else {
                return table.last ?? blank
            }
        }
        return blank
    }
    
   
    
    // U is for update
    mutating func update(oldRow:Row,newRow:Row,isActive:Bool)->ErrorType{
            if let index = table.firstIndex(where: {
                row in row.id == newRow.id}){
                if isActive{
                    table[index] = newRow
                    return .noError
                } else { // inactive account can only toggle activity
                    if isActive{
                        table[index].isActive = true
                        return .noError
                    } else {
                        return .readOnly
                    }
                }
            }
            return .recordNotFound
        } 
    
    mutating func update(id:Row.ID,newRow:Row,isActive:Bool)->ErrorType{
        if let index = index(id: id){
            if isActive{
                table[index] = newRow
                return .noError
            } else { // inactive account can only toggle activity
                if newRow.isActive{
                    table[index].isActive = true
                    return .noError
                } else {
                    return .readOnly
                 }
            }
        }
        return .recordNotFound
    }
    
    // D is for delete
    mutating func remove(id:Row.ID)->ErrorType{
        if let index = index(id: id){
            table.remove(at: index)
            return .noError
        } else {
            return .noDelete
        }
    }
}

