//
//  CRUDAction.swift
//  My App
//
//  Created by Steven Lipton on 6/3/25.
//

import SwiftUI

enum CRUDAction:String,CaseIterable{

    case add = "Add"
    case update = "Update"
    case delete = "Delete"
    case search = "Search"
    case view = "View"
    
    
    
    var icon:some View{
        switch self{
        case .add: return Image(systemName: "plus.app.fill")
        case .update: return Image(systemName:"square.and.pencil")
        case .search: return Image(systemName:"magnifyingglass")
        case .delete: return Image(systemName: "trash.fill")
        case .view: return Image(systemName:"binoculars.fill")
        }
    }
}
