import SwiftUI


class AccountCategory:Identifiable{
    var id:Int
    var name:String
    //added 5/2/2025 - cannot delete accounts, but can inactivate
    var active:Bool = true
    
    init(id: Int, name: String) {
        self.id = id
        self.name = name
    }
    
    
}

class AccountCategories{
    var accountCategories:[AccountCategory]
    init(){
        self.accountCategories = [
            AccountCategory(id: 0, name: "N/A"),
            AccountCategory(id: 1, name:"Asset"),
            AccountCategory(id: 2, name:"Liability"),
            AccountCategory(id: 3, name:"Investment"),
            AccountCategory(id: 4, name:"Revenue"),
            AccountCategory(id: 5, name:"COGS"),
            AccountCategory(id: 6, name:"Expenses")
        ]
    }
    
    func add(id:Int,name:String){
        //if not existing, add the category
        if accountCategories.firstIndex(where: {$0.id == id}) == nil {
            accountCategories.append(AccountCategory(id: id, name: name))
        }
    }
}


class Account:Identifiable,Equatable{
    var accountNumber:String
   
    var accountName:String
    var accountCategory: Int
    var isActive:Bool
    var creditTotal:Float
    var debitTotal:Float
    
    var id:String{accountNumber}
    var total:Float{debitTotal - creditTotal}
    
    init(accountNumber: String, accountName: String, accountCategory: Int) {
        self.accountNumber = accountNumber
        self.accountName = accountName
        self.accountCategory = accountCategory
        self.isActive = true
        self.creditTotal = 0
        self.debitTotal = 0
    }
    
    static var blank:Account{Account(accountNumber:"",accountName:"",accountCategory: 0)}
   
    //satisfies the equatable protocol
    static func == (lhs: Account, rhs: Account) -> Bool {
        return
            lhs.accountNumber == rhs.accountNumber &&
            lhs.accountName == rhs.accountName &&
            lhs.accountCategory == rhs.accountCategory &&
            lhs.isActive == rhs.isActive &&
            lhs.creditTotal == rhs.creditTotal &&
            lhs.debitTotal == rhs.debitTotal
        
    }
    
}



