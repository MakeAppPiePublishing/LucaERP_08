import Foundation



class JournalTransaction:Identifiable{
    // Id becomes two keys 
    var docId:Int
    var row:Int
    var date:Date
    var account:String
    var description:String
    var amount:Double
    var creditDebit:CreditDebit
    
    //chaged id to identifiy both parts ofthe key. 
    var id:Int{ 
        docId * 100 + row  
    }
   
    init(docId:Int,row:Int,account:String,amount:Double,creditDebit:CreditDebit){
        //id is no longer automatically assigned, replaced with docId and row
       // id = globalJournalEntryID
       // globalJournalEntryID += 1
        self.docId = docId
        self.row = row
        
        self.date = Date()
        self.account = account
        let coa = ChartOfAccounts().accounts
        if let accountInfo = coa.first(where:{$0.accountNumber == account}){
                self.description = accountInfo.accountName
            }else {
                self.description = "Account not found"
            }
        self.amount = amount
        self.creditDebit = creditDebit
    }
    
    
    
    func numAmount()->Double{
        return amount * creditDebit.rawValue
    }
    
    
}

// the testing version prior to implementing persistance

class JournalTransactions{
    
    var transactions:[JournalTransaction] 
    
    init(){
        self.transactions = testTransactions 
    }
    
    //changed name to testTransactions
    var testTransactions = [
        JournalTransaction(docId:100,row: 0, account:"321000", amount: 1000, creditDebit: .credit),
        JournalTransaction(docId:100,row: 1,account:"111000", amount: 1000, creditDebit: .debit),
        JournalTransaction(docId:101,row: 0,account:"131100", amount: 300, creditDebit: .debit),
        JournalTransaction(docId:101,row: 1,account:"111000", amount: 300, creditDebit: .credit),
        JournalTransaction(docId:102,row: 0,account:"131100", amount: 100, creditDebit: .debit),
        JournalTransaction(docId:102,row: 1,account:"211000", amount: 100, creditDebit: .credit),
        JournalTransaction(docId:103,row: 0,account:"621000", amount: 300, creditDebit: .debit),
        JournalTransaction(docId:103,row: 1,account:"111000", amount: 300, creditDebit: .credit),
        JournalTransaction(docId:104,row: 0,account:"652100", amount: 200, creditDebit: .debit),
        JournalTransaction(docId:104,row: 1,account:"111000", amount: 200, creditDebit: .credit),
        JournalTransaction(docId:105,row: 0,account:"111000", amount: 5000, creditDebit: .debit),
        JournalTransaction(docId:105,row: 1,account:"411000", amount: 5000, creditDebit: .credit),
        JournalTransaction(docId:105,row: 2,account:"511000", amount: 400, creditDebit: .debit),
        //JournalTransaction(docId:105,row:3,account: "111000",amount: 400,creditDebit: .credit)
    ]
}
