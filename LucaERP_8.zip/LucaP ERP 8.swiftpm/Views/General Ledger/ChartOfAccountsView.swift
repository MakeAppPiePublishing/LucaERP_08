import SwiftUI

struct LPChartOfAccountsListView: View {
    
    @Binding var selected:Account //changed to Account from index 5/3/25 
    @Binding var isPresented:Bool
    var accounts:ChartOfAccounts = ChartOfAccounts()
    var accountCategories = AccountCategories().accountCategories
    
    // TODO 5/2/25 moved to the model
    var sortedAccounts:[Account]{
        accounts.sortedAccounts()
    }
// TODO  removed 5/3/25 - passing ID back instead. 
    func selectedIndex(_ account:Account) -> Int!{
        sortedAccounts.firstIndex{$0.id == account.id}
    }
    
    var body: some View {
        VStack{
            List{  //Changed 5/2/25
                ForEach(accounts.sortedAccounts()){account in 
                    VStack{
                        Divider()
                        HStack{
                            Text(account.accountNumber)
                            Text(account.accountName)
                            Spacer()
                            Text(accountCategories[account.accountCategory].name)
                        }
                        .onTapGesture{
                            selected = account
                            isPresented = false
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    LPChartOfAccountsListView(selected:.constant( Account(accountNumber: "10001", accountName: "Cash", accountCategory: 1) ), isPresented: .constant(true))
}
