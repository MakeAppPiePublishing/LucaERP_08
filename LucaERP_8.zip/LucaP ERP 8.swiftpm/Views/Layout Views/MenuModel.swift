import SwiftUI


struct LucaMenuItem:Identifiable,Hashable{
    var id:Int
    var title:String
    var content:some View{ Text(title) }
}


class LucaMenuModel{
    var menuItems:[LucaMenuItem] = []
    
    init(titles:[String]){
        var id = 0
    for title in  titles{
        menuItems.append(LucaMenuItem(id: id, title: title))
        id += 1
    }   
    }
}


