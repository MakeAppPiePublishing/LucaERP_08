import SwiftUI
let choiceArray = [(0,"Eeny"),(1,"Meeny"),(2,"Miny"),(3,"Mo")] 
struct ContentView: View {
    @State var path = "Finance > Accounting > Chart Of Accounts"
    var body: some View {
        VStack(alignment:.center) {
            ContentHeaderView(path:$path)
            LPChartOfAccountsFormView()
            Spacer()
        }
    }
}
